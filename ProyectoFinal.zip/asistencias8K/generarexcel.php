<?php
    header("content-type: application/xls");
    header("Content-disposition: attachment; filename = Registro_alum.xls");  
?>
<?php
  include_once "./config/conexion-asistencias.php";
  $sentencia = $bd->query("select * from registro_alum");
  $registro_alum = $sentencia->fetchAll(PDO::FETCH_OBJ);
  //print_r($registro_alum);
  ?>
  <table border="2" cellspacing="2" WIDTH=50% ALIGN=center style="background-color:rgb(192, 195, 195);">

    <?php
    if (isset($_GET['mensaje']) and $_GET['mensaje'] == 'error') {
    ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong></strong>ㅤㅤㅤError!ㅤVuelve a intentar
      </div>
    <?php
    }
    ?>
    <style>
      .table {
        margin-left: 5px;
        margin-right: 5px;
      }

      .tbody {
        margin-left: 5px;
        margin-right: 5px;
      }
      .card{
        background-color: #CFE2FF;
      }
    </style>

    <div class="table-responsive">

      <table class="table table-primary">
        <div class="card">
          <div class="card-body">
            <h3>Registro de asistencia</h3>
          </div>
        </div>
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Matricula</th>
            <th scope="col">Nombre</th>
            <th scope="col">Semestre</th>
            <th scope="col">Grupo</th>
            <th scope="col">Fecha</th>
            <th scope="col">Hora<br>entrada</th>
            <th scope="col">Hora<br>salida</th>
            <th scope="col">Actividad</th>
          </tr>
        </thead>
        <tbody>
          <?php
          foreach ($registro_alum as $dato) {
          ?>

            <tr>
              <td scope="row"><?php echo $dato->id_registro; ?></td>
              <td><?php echo $dato->matricula; ?></td>
              <td><?php echo $dato->full_name; ?></td>
              <td><?php echo $dato->semestre; ?></td>
              <td><?php echo $dato->grupo; ?></td>
              <td><?php echo $dato->fecha_regis; ?></td>
              <td><?php echo $dato->hora_entrada; ?></td>
              <td><?php echo $dato->hora_salida; ?></td>
              <td><?php echo $dato->actividad; ?></td>
            </tr>
          <?php
          }
          ?>

        </tbody>
      </table>