<?php 
require_once('db-connect.php');
if(!isset($_GET['id'])){
    echo "<script> alert('Undefined Schedule ID.'); location.replace('./') </script>";
    $conn->close();
    exit;
}

$delete = $conn->query("DELETE FROM `agendahorario` where id = '{$_GET['id']}'");
if($delete){
    echo "<script> alert('La clase fue borrada satisfactoriamente.'); location.replace('agenda.php') </script>";
}else{
    echo "<pre>";
    echo "Ha ocurrido un error.<br>";
    echo "Error: ".$conn->error."<br>";
    echo "SQL: ".$sql."<br>";
    echo "</pre>";
}
$conn->close();

?>