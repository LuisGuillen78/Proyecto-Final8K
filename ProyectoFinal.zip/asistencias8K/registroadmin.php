<!DOCTYPE html>
<html lang="es-MX">

<head>
  <title>Registro de Administradores</title>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="./src/css/estilos.css" rel="stylesheet" type="text/css">
  <link rel="shortcut icon" type="image/x-icon" href="./src/img/asistencia.svg" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;400&display=swap" rel="stylesheet">

</head>

<body style="background-color:rgb(0, 42, 97);">
  <img src="./src/img/LogoNuevo.png" 5 WIDTH=100% ALIGN=Center>
  <br>
  <br>
  <br>
  <br>
  <br>

  <table border="2" cellspacing="2" WIDTH=50% ALIGN=center style="background-color:rgb(192, 195, 195);">
    <tr>
      <th>
        <!--Inicio alerta -->
        <?php
          if(isset($_GET['mensaje']) and $_GET['mensaje'] == 'falta'){
        ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <strong></strong>ㅤㅤㅤ  Error !ㅤLlena todos los campos</div>
        <?php
          }
        ?>



        <?php
          if(isset($_GET['mensaje']) and $_GET['mensaje'] == 'registrado'){
        ?>
        <div class="alert alert-sucess alert-dismissible fade show" role="alert">
          <strong></strong>ㅤㅤㅤRegistrado!ㅤDatos enviados</div>
        <?php
          }
        ?>
        <!--Fin Alerta -->
        <h1>Datos Del Administrador</h1>
        <h2>Registro</h2>

        <div container class="fluid">
          <form method="POST" action="registroad.php">

            <input type="hidden" name="oculto" value="1">

            <label for="matricula">Matricula</label>
            <input type="text" id="matri" name="matri" placeholder="A19043" autofocus required><br><br>

            <label for="full-name">Nombre completo</label>
            <input type="text" id="full-name" name="full-name" placeholder="Rigoberto Perez" autofocus required><br><br>

            <label for="semestre">Correo</label>
            <input type="text" id="correo" name="Username" placeholder="@unach.mx" autofocus required><br><br>

            <label for="grupo">Contraseña</label>
            <input type="password" id="pass" name="Pass" placeholder="*****" autofocus required><br><br>
        </div>
         <div class="d-grid gap-2 d-md-flex justify-content-md-end">
         <div class="d-grid gap-2 d-md-flex justify-content-md-end">

            <input type="submit" value="Registrar"><br>
        </div></form>

        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <form method="POST" action="src/vistas/archivo-protegido.php">
              <input  type="submit"  value="Regresar" name="btnregistrar" ><br>
        </div>
          </form>
    </tr>
  </table>
</body>

</html>