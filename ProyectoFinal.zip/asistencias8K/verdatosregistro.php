<!DOCTYPE html>
<html lang="es-MX">

<head>
  <title>Tabla de asistencia</title>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="./src/css/estilos.css" rel="stylesheet" type="text/css">
  <link rel="shortcut icon" type="image/x-icon" href="./src/img/asistencia.svg" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;400&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">


</head>

<body style="background-color:rgb(0, 42, 97);">
  <img src="./src/img/LogoNuevo.png" 5 WIDTH=100% ALIGN=Center>
  <br>
  <br>
  <?php
  include_once "./config/conexion-asistencias.php";
  $sentencia = $bd->query("select * from registro_alum");
  $registro_alum = $sentencia->fetchAll(PDO::FETCH_OBJ);
  //print_r($registro_alum);
  ?>
  <table border="2" cellspacing="2" WIDTH=50% ALIGN=center style="background-color:rgb(192, 195, 195);">

    <?php
    if (isset($_GET['mensaje']) and $_GET['mensaje'] == 'error') {
    ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong></strong>ㅤㅤㅤError!ㅤVuelve a intentar
      </div>
    <?php
    }
    ?>
    <style>
      .table {
        margin-left: 5px;
        margin-right: 5px;
      }

      .tbody {
        margin-left: 5px;
        margin-right: 5px;
      }
      .card{
        background-color: #000000;

      }


      h4{

        font-family: sans-serif !important;
        color: #F7F4F4 !important;

      }
    </style>

    <div class="table-responsive">

      <table class="table table-bordered table-dark">
        <div class="card">
          <div class="card-body">
            <h4>Registro de Asistencias</h4>
          </div>
        </div>
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Matricula</th>
            <th scope="col">Nombre</th>
            <th scope="col">Semestre</th>
            <th scope="col">Grupo</th>
            <th scope="col">Fecha</th>
            <th scope="col">Hora<br>entrada</th>
            <th scope="col">Hora<br>salida</th>
            <th scope="col">Actividad</th>
            <th scope="col">Opciones</th>
            <th scope="col">⠀</th>
          </tr>
        </thead>
        <tbody>
          <?php
          foreach ($registro_alum as $dato) {
          ?>

            <tr>
              <td scope="row"><?php echo $dato->id_registro; ?></td>
              <td><?php echo $dato->matricula; ?></td>
              <td><?php echo $dato->full_name; ?></td>
              <td><?php echo $dato->semestre; ?></td>
              <td><?php echo $dato->grupo; ?></td>
              <td><?php echo $dato->fecha_regis; ?></td>
              <td><?php echo $dato->hora_entrada; ?></td>
              <td><?php echo $dato->hora_salida; ?></td>
              <td><?php echo $dato->actividad; ?></td>
              <td><a class="text-sucess" href="editar.php?id_registro=<?php echo $dato->id_registro; ?>"><i class="bi bi-pencil-square"></i></a></td>

              <td><a class="text-danger" href="eliminaregis.php?id_registro=<?php echo $dato->id_registro; ?>"><i class="bi bi-trash3"></i></a></td>
            </tr>

          <?php
          }
          ?>

        </tbody>
      </table>
    </div>
  </table>
  <a href="./src/vistas/archivo-protegido.php" type="button" class="btn btn-primary" ALIGN="right">Menú</a>
  <a href="generarexcel.php" type="button" class="btn btn-success" ALIGN="right">Excel</a>


</body>

</html>