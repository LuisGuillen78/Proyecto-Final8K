<!doctype html>
<html lang="en">

<head>
    <title>Editar datos</title>
    <style>
      header {
        background-color: #D2A92D;
      }
    </style>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="shortcut icon" type="image/x-icon" href="./src/img/edit-button.svg" />

</head>

<body style="background-color: rgb(0, 42, 97) ;">
    <header class="py-3">
        <h3 class="text-center">Editar Datos</h3>
    </header>
    <main>
        <?php
        include_once 'config/conexion-asistencias.php';
        $id_registro = $_GET['id_registro'];

        $sentencia = $bd->prepare("select * from registro_alum where id_registro = ?;");
        $sentencia->execute([$id_registro]);
        $registro_alum = $sentencia->fetch(PDO::FETCH_OBJ);
        //print_r($registro_alum);
        ?>

        <div class="container mt-5" >
            <div class="row justify-content-center">
                <div class="col-md-5">
                    <div class="card">
                        <div class="card-header">
                            
                        </div>
                        <form method="POST" action="editarproceso.php">
                            <div class="text-center">

                            <input type="hidden" name="id_registro" 
                            value="<?php echo $registro_alum ->id_registro ?>">
                            <br>

                            <div class="d-grid gap-6 d-md-flex justify-content-md-end">
                            <div class="form-group col-md-6">
                            <label for="matricula"> Matricula</label></div> <div class="form-group col-md-6">
                            <input class="form-control bg-light" type="text" id="enrollment" name="enrollment" required 
                            value="<?php echo $registro_alum ->matricula ?>"> </div></div><br>
                           

                            <div class="d-grid gap-6 d-md-flex justify-content-md-end">
                            <div class="form-group col-md-6">
                            <label for="full-name">Nombre completo</label></div> <div class="form-group col-md-6">
                            <input class="form-control bg-light" type="text" id="full-name" name="full-name" required
                            value="<?php echo $registro_alum ->full_name?>"><br>
                            </div></div>
                            
                            <div class="d-grid gap-6 d-md-flex justify-content-md-end">
                            <div class="form-group col-md-6">
                            <label for="semestre">Semestre</label></div> <div class="form-group col-md-6">
                            <input class="form-control bg-light" type="text" id="semesters" name="semesters" required
                            value="<?php echo $registro_alum ->semestre?>"><br>
                            </div></div>

                            <div class="d-grid gap-6 d-md-flex justify-content-md-end">
                            <div class="form-group col-md-6">
                            <label for="grupo">Grupo</label></div> <div class="form-group col-md-6">
                            <input class="form-control bg-light" type="text" id="group" name="group" required
                            value="<?php echo $registro_alum ->grupo?>"><br>
                            </div></div>

                            <div class="d-grid gap-6 d-md-flex justify-content-md-end">
                            <div class="form-group col-md-6">
                            <label for="fecha">Fecha</label></div> <div class="form-group col-md-6">
                            <input class="form-control bg-light" type="date" id="fecha" name="fechaa" required
                            value="<?php echo $registro_alum ->fecha_regis?>"><br>
                            </div></div>

                            <div class="d-grid gap-6 d-md-flex justify-content-md-end">
                            <div class="form-group col-md-6">
                            <label for="hora-de-entrada">Hora de entrada</label></div> <div class="form-group col-md-6">
                            <input class="form-control bg-light" type="time" id="entry-time" name="entry-time" required
                            value="<?php echo $registro_alum ->hora_entrada?>"><br>
                            </div></div>

                            <div class="d-grid gap-6 d-md-flex justify-content-md-end">
                            <div class="form-group col-md-6">
                            <label for="hora-de-salida">Hora de Salida</label></div> <div class="form-group col-md-6">
                            <input class="form-control bg-light" type="time" id="exit-time" name="exit-time" required
                            value="<?php echo $registro_alum ->hora_salida?>"><br></div></div>
                            
                            <div class="d-grid gap-6 d-md-flex justify-content-md-end">
                            <div class="form-group col-md-6">
                            <label for="Actividad">Actividad</label></div> <div class="form-group col-md-6">
                            <input class="form-control bg-light" type="text" id="group" name="activity" required
                            value="<?php echo $registro_alum ->actividad?>"><br>
                            </div></div>

                            
                            <input type="submit" class="btn btn-success" value="Guardar"><br><br>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <br>
    <footer class="bg-light text-center text-lg-start">
        <!-- Copyright -->
        <div class="text-center p-3" style="background-color: #D2A92D;">
            <h5>UNACH 2023 - FCA C-1</h5>
        </div>
    </footer>
</body>

</html>