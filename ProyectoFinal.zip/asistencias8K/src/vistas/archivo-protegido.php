<?php
session_start();
if($_SESSION==null || $_SESSION=''){
    header("Location: ../../loginadmin.php");
echo '<div style="position: absolute" class="alert alert-danger justify-content-center">NO TIENES ACCESO A LA PÁGINA</div>';
  die();
}
?>






<!DOCTYPE html>
<html>
<STYLE>A {text-decoration: none;} </STYLE>

<head>
    <title> MENU</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/src/css/estilos.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" type="image/x-icon" href="/src/img/asistencia.svg"/>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;400&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
</head>

<body style="background-color:rgb(0, 42, 97);">
<img src="./src/img/logoNuevo.png" WIDTH=100% ALIGN=rigth><br><br>
    <table
      border="2"
      cellspacing="2"
      width="50%"
      align="center"
      style="background-color: rgb(201, 205, 205)">

      <tr>
        <th>
          <div class="d-grid gap-2 d-md-flex justify-content-md-center">
          <h1>Laboratorio de Cómputo FCA-1</h1><br></div><br>
          <div class="d-grid gap-2 d-md-flex justify-content-md-center">
          <h2>Menú</h2>
          </div>
          <br>
          <br>

          <form method="POST" action="../../agenda.php">
          <div class="d-grid gap-2 d-md-flex justify-content-md-end"><div class="form-group col-md-7">
          <img src="./src/img/asistencia.svg" width="58" height="65"/>
          <button type="submit" class="btn btn-primary" value="agenda" name="agenda">Clases agendadas</button>
          </form></div></div><br>

          <form method="POST" action="../../verdatosregistro.php">
          <div class="d-grid gap-2 d-md-flex justify-content-md-end"><div class="form-group col-md-7">
          <img src="./src/img/asistencia.svg" width="58" height="65"/>
          <button type="submit" class="btn btn-primary" value="registro" name="registrosasistencia">Registros de asistencia</button>
          </form></div></div><br>

          <form method="POST" action="../../registroadmin.php">
          <div class="d-grid gap-2 d-md-flex justify-content-md-end"><div class="form-group col-md-7">
          <img src="./src/img/asistencia.svg" width="58" height="65"/>
          <button type="submit" class="btn btn-primary" value="Nuevo" name="Nuevo_Admin">Registrar Nuevo Administrador</button>
          </form></div></div><br>


          <form method="POST" action="salir.php">
          <div class="d-grid gap-2 d-md-flex justify-content-md-center">
          <button type="submit" class="btn btn-danger" value="Regresar" name="cerrarsesion">Salir</button>
          </form></div><br>

        </th>
      </tr>
    </table>

</body>

</html>