<?php
session_start();
$conn = mysqli_connect('localhost','root','','bdasistencia8k') or die ('Conexion Fallida');

?>

<!DOCTYPE html>
<html lang="es-MX">

<head>
  <title>Login</title>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="./src/css/estilos.css" rel="stylesheet" type="text/css">
  <link rel="shortcut icon" type="image/x-icon" href="./src/img/lock7.svg"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous"/>
    
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;400&display=swap" rel="stylesheet">

</head>
  <body>
      <body style="background-color:rgb(0, 42, 97);">
      <img src="./src/img/logoNuevo.png" WIDTH=100% ALIGN=rigth><br><br>

      <table border="2" id="mi-elemento" cellspacing="2" WIDTH=50% ALIGN=center style="background-color:rgb(192, 195, 195);">
        <tr>
          <th> 
          <div class="d-flex justify-content-center">
          
          <h1>Laboratorio de Cómputo FCA-1</h1></div>
          <div class="d-flex justify-content-center">
          <h2>Iniciar sesión</h2></div>
          <div class="d-flex justify-content-center">
          <img src="./src/img/usuario.svg" WIDTH=50% ALIGN=Center >
          </div>
            

            <form  action="loginadmin.php" method="post">
            <div class="d-flex justify-content-center">
              <input type="text" placeholder="Usuario"    name="Username"    id="" autofocus required></div>
              <div class="d-flex justify-content-center">
              <input type="password" placeholder="Contraseña" name="Pass" id="" autofocus required> 
              </div>
              
              <div class="d-flex justify-content-center">
              
              <?php
              if (isset($_POST['Ingresar'])){

                  $Username= $_POST['Username'];
                  $Pass= $_POST['Pass'];
                
                  $select = mysqli_query($conn,"SELECT * FROM registro_admin WHERE Username= '$Username' AND Pass= '$Pass'");
              
                  $row = mysqli_fetch_array($select);


                  if(is_array($row)){
                    $_SESSION["Username"] = $row ['Username'];
                    $_SESSION["Pass"] = $row['Pass'];
                  } else {
                        
                    echo '<div style="position: absolute" class="alert alert-danger justify-content-center">Usuario o Contraseña Incorrecto</div>';
                        echo '<script type= text/javascript">';
                        echo 'alert("Contraseña o Usuario Incorrecto");';
                        echo 'window.location.href = "loginadmin.php"';
                        echo '</script>';

                  }

              }

              if(isset($_SESSION['Username'])){
                header("Location: src/vistas/archivo-protegido.php");
              }

              ?>
            
              </div>
             
              
              <div class="d-grid gap-2 d-md-flex justify-content-md-end">
              <div  class="d-grid gap-2 d-md-flex justify-content-md-end">
              <input type="submit" value="Iniciar sesión" name="Ingresar" >
              </div>
              </form>
              
              
              
              
            <div  class="d-grid gap-2 d-md-flex justify-content-md-center">
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <form method="POST" action="asistenciaalum.php">
            <input  type="submit"  value="Asistencia Alumno" name="btnregistrar" ><br>
            </div></div>
            </form>
          

        </tr>
      </table>
  </body>
</html>